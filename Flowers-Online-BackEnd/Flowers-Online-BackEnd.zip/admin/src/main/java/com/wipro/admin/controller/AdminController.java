package com.wipro.admin.controller;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.admin.entity.Product;
import com.wipro.admin.feign.adminFeign;

@RestController
@RequestMapping("/api/v1/admin")
@CrossOrigin(origins = {"*"})
public class AdminController {
	
	@Autowired
	adminFeign adminfeign;
	
	
	@GetMapping("/product/getAllProducts/{category}")
	public List<Product> getProduct(@PathVariable String category) {
		return adminfeign.getAllProductsByCategory(category);
		
	}
	
	
	@PostMapping("/product/addProduct")
	public Map<String,Boolean> saveProduct(@RequestBody Product product) throws IOException {
		return adminfeign.saveProduct(product);
		
	}
	
	
	@DeleteMapping("/product/delete/{productId}")
	public Map<String,Boolean> deleteById(@PathVariable long productId) {
		return adminfeign.deleteById(productId);
	}
	
	
	
	
	
	
	
	
	@PutMapping("/product/update")	
	public Map<String,Boolean> updateProduct(@RequestBody Product p) throws Exception{
		return adminfeign.updateProduct(p);
	}
	
	
	@PutMapping("/product/updateQuantity")
	public Product updateProductQuantity(@RequestBody Product p) {
		return adminfeign.updateProductQuantity(p);
		
	}
	
	
	@GetMapping("/product/getProduct/{category}/{id}")
	public Product getProduct(@PathVariable long id,@PathVariable String category) {
		
		return adminfeign.getProduct(id, category);
	}

}
